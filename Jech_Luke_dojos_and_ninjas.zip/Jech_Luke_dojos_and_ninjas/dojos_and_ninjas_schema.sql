select dojo_id from ninjas
WHERE id = 9;
